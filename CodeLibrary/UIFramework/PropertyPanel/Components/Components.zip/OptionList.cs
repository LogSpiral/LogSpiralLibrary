﻿using ImproveGame.UIFramework.SUIElements;
using System.Collections;
using Terraria.ModLoader.Config;
using ImproveGame.UIFramework.BaseViews;
using ImproveGame.Packets;

namespace LogSpiralLibrary.CodeLibrary.UIFramework.PropertyPanel.Components;

public class OptionList : OptionCollections
{
    private Type listType;

    protected override bool CanItemBeAdded => true;

    protected override void AddItem()
    {
        ((IList)Data).Add(CreateCollectionElementInstance(listType));
        NetSyncManually();
    }

    protected override void ClearCollection()
    {
        ((IList)Data).Clear();
        NetSyncManually();
    }

    protected override void InitializeCollection()
    {
        Data = Activator.CreateInstance(typeof(List<>).MakeGenericType(listType));
        SetValueDirect(Data);
    }


    protected override void PrepareTypes()
    {
        listType = VariableInfo.Type.GetGenericArguments()[0];
        JsonDefaultListValueAttribute = ConfigManager.GetCustomAttributeFromCollectionMemberThenElementType<JsonDefaultListValueAttribute>(VariableInfo.MemberInfo, listType);
    }

    protected override void SetupList()
    {
        //ListPanel.Clear();
        OptionView.ListView.RemoveAllChildren();
        IList list = VariableInfo.GetValue(Item) as IList;
        int count = list.Count;
        for (int i = 0; i < count; i++)
        {
            var deleteButton = new SUICross()
            {
                Spacing = new Vector2(4f, 10f),
                Top = { Pixels = 8f },
                BgColor = Color.Black * 0.4f,
                Rounded = new Vector4(4f),
                Width = new(25, .0f),
                Height = new(25, .0f),
            };
            int idx = i;
            deleteButton.OnLeftClick += (evt, elem) =>
            {
                ((IList)Data).RemoveAt(idx);
                SetupList();
                pendingChanges = true;
                NetSyncManually();
            };

            var e = WrapIt(OptionView.ListView, Config, VariableInfo, Item, list, listType, i, this, preLabelAppend: deleteButton.JoinParent);

            if (e.Elements[0] is OptionLabelElement label)
            {
                label.Left = new(30, 0);
            }
            e.OnLeftMouseDown += (evt, elem) =>
            {
                var dimension = elem.GetDimensions();
                if (evt.Target != elem) return;

                var c = 0;
                float h = 0;
                while (c < idx)
                {
                    h += OptionView.ListView.Elements[c].Height.Pixels;
                    c++;
                }
                var pos = new Vector2(0, h - OptionView.ScrollBar.TargetScrollPosition.Y);
                offset = evt.MousePosition - pos - GetDimensions().Position();


                float deltaY = evt.MousePosition.Y - OptionView.GetDimensions().Y - h;
                if (deltaY < elem.Height.Pixels * .5f)
                {
                    e.RelativeMode = RelativeMode.None;
                    e.Remove();
                    e.JoinParent(OptionView.MaskView);
                    OptionView.Recalculate();
                    currentDraggingOption = e;
                }
            };
            e.OnUpdate += (elem) =>
            {
                if (currentDraggingOption == null || currentDraggingOption != elem)
                    return;
                var pos = Main.MouseScreen - offset - GetDimensions().Position();
                e.SetPosPixels(pos);
                e.Recalculate();
            };
            e.OnLeftMouseUp += (evt, elem) =>
            {

                if (currentDraggingOption != elem) return;
                currentDraggingOption = null;
                int length = OptionView.ListView.Children.Count();
                var selfDimension = elem.GetDimensions();
                e.Remove();
                int n = 0;
                var y = selfDimension.Y;
                var en = OptionView.ListView.Children.GetEnumerator();
                while (en.MoveNext())
                {
                    var cur = en.Current;
                    var curDimension = cur.GetDimensions();
                    if (y < curDimension.Center().Y)
                        break;
                    n++;
                }
                var dummy = list[idx];
                list.RemoveAt(idx);
                list.Insert(n, dummy);
                SetupList();
                pendingChanges = true;

                NetSyncManually();
            };
            /*e.OnRightMouseDown += (evt, elem) =>
            {
                if (evt.Target != elem) return;
                e.SetValueDirect(CreateCollectionElementInstance(listType));
            };*/
        }
        OptionView.Recalculate();
        Height.Set(Math.Min((OptionView.ListView.Children.Any() ? OptionView.ListView.Height.Pixels : 0) + 70, 360), 0);//不知道为什么MaxHeight不管用了
        //TODO 排版上改成网格式而不是纵向列表

    }
    public override void DrawChildren(SpriteBatch spriteBatch)
    {
        base.DrawChildren(spriteBatch);
        if (currentDraggingOption != null) 
        {
            float y = Main.mouseY;
            var en = OptionView.ListView.Children.GetEnumerator();

            CalculatedStyle curDimension = default;
            bool last = true;
            while (en.MoveNext())
            {
                var cur = en.Current;
                curDimension = cur.GetDimensions();
                if (y < curDimension.Center().Y)
                {
                    y = curDimension.Position().Y;
                    last = false;
                    break;
                }
            }
            if (last)
                y = curDimension.Position().Y + curDimension.Height;
            spriteBatch.Draw(TextureAssets.MagicPixel.Value, new Vector2(GetDimensions().X - 10, y), new Rectangle(0, 0, 1, 1), Color.White, 0, new Vector2(.5f), new Vector2(240, 2), 0, 0);
            goto label;
        }
        foreach (var elem in OptionView.ListView.Elements)
        {
            var dimemsion = elem.GetDimensions();
            if (elem.IsMouseHovering && Main.mouseY < dimemsion.Y + dimemsion.Height * .5f)
                goto label;
        }
        return;
        label:
        if (!Main.instance._mouseTextCache.isValid)
            Main.instance.MouseText("[i:897]", 0, 0, Main.mouseX + 16, Main.mouseY - 10);
    }
    OptionBase currentDraggingOption;
    Vector2 offset;
}

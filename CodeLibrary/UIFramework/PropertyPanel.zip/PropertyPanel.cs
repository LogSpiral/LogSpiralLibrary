﻿using SilkyUIFramework;
using SilkyUIFramework.BasicElements;

namespace LogSpiralLibrary.CodeLibrary.UIFramework.PropertyPanel;

public class PropertyPanel(UIElementGroup controlTarget) : SUIDraggableView(controlTarget)
{

}
